### Hexlet tests and linter status:
[![Actions Status](https://github.com/VictorVangeli/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/VictorVangeli/python-project-49/actions)

### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/05cb6ed980734667d5fb/maintainability)](https://codeclimate.com/github/VictorVangeli/python-project-49/maintainability)

### ASCCIINEMA:

1. Игра: "Проверка на чётность"

[![asciicast](https://asciinema.org/a/jKNyxUzBHMq60sBdwi9vNmuNL.svg)](https://asciinema.org/a/jKNyxUzBHMq60sBdwi9vNmuNL)

2. Игра: «Калькулятор»

[![asciicast](https://asciinema.org/a/u3YpgvS3P2BwCx5kH6bAzZuEk.svg)](https://asciinema.org/a/u3YpgvS3P2BwCx5kH6bAzZuEk)

3. Игра: "Наименьший общий делитель"

[![asciicast](https://asciinema.org/a/wsLkUms6BcS2U30evjp4mJPag.svg)](https://asciinema.org/a/wsLkUms6BcS2U30evjp4mJPag)

4. Игра «Арифметическая прогрессия»

[![asciicast](https://asciinema.org/a/Ih4rvR9QDnLXmFa1NWHEAsYFY.svg)](https://asciinema.org/a/Ih4rvR9QDnLXmFa1NWHEAsYFY)